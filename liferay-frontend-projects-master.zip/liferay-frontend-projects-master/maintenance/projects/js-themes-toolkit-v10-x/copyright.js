/**
 * SPDX-FileCopyrightText: © <%= YEAR %> Liferay, Inc. <https://liferay.com>
 * SPDX-License-Identifier: MIT
 */

