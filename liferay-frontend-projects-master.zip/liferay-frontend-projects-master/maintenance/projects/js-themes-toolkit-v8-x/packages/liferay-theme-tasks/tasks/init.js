/**
 * SPDX-FileCopyrightText: © 2017 Liferay, Inc. <https://liferay.com>
 * SPDX-License-Identifier: MIT
 */

'use strict';

module.exports = function (options) {
	const gulp = options.gulp;

	gulp.task('init', ['plugin:init']);
};
