/**
 * SPDX-FileCopyrightText: © 2017 Liferay, Inc. <https://liferay.com>
 * SPDX-License-Identifier: MIT
 */

'use strict';

var gulp = require('gulp');
var liferayPluginTasks = require('liferay-plugin-node-tasks');

liferayPluginTasks.registerTasks({
	gulp,
});
