# Contributing to Liferay frontend projects

In order to make the guidance in this document easy to cite from other projects, it is split up into the following sections:

-   [Commit message format](general/commit_messages.md)
-   [Linking](general/linking.md)
