---
name: '⚙ @liferay/js-insights'
about: Issues related to the @liferay/js-insights package
labels: npm-tools, js-insights
---

### Issue type (mark with `x`)

-   [ ] :thinking: Question
-   [ ] :bug: Bug report
-   [ ] :gift: Feature request
-   [ ] :woman_shrugging: Other

### Description

**Desired behavior:**

**Current behavior:**

**Repro instructions (if applicable):**

**Other information (environment, versions etc):**
