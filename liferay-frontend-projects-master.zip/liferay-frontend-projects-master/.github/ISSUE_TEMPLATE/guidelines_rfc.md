---
name: 💍 Guidelines Proposal
about: Issues for proposing a change to our frontend practices
labels: guidelines,rfc
---

<!--

Before making a proposal, have you used the issue search functionality?

-->

## What is your proposal?

## Why would adopting this proposal be beneficial?

## What are the alternatives to this proposal?
