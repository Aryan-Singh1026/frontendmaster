---
name: '📦 Liferay Themes Toolkit'
about: Issues related to the Liferay Themes Toolkit
labels: js-themes-toolkit
---

### Issue type (mark with `x`)

-   [ ] :thinking: Question
-   [ ] :bug: Bug report
-   [ ] :gift: Feature request
-   [ ] :woman_shrugging: Other

### Version (mark with `x`)

-   [ ] :eight: v8.x
-   [ ] :nine: v9.x
-   [ ] :keycap_ten: v10.x or higher

### Description

**Desired behavior:**

**Current behavior:**

**Repro instructions (if applicable):**

**Other information (environment, versions etc):**
