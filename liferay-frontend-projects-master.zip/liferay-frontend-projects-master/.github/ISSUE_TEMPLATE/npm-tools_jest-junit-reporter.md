---
name: '⚙ @liferay/jest-junit-reporter'
about: Issues related to the @liferay/jest-junit-reporter package
labels: npm-tools, jest-junit-reporter
---

### Issue type (mark with `x`)

-   [ ] :thinking: Question
-   [ ] :bug: Bug report
-   [ ] :gift: Feature request
-   [ ] :woman_shrugging: Other

### Description

**Desired behavior:**

**Current behavior:**

**Repro instructions (if applicable):**

**Other information (environment, versions etc):**
