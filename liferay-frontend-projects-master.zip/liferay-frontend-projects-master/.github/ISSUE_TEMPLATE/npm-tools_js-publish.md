---
name: '⚙ @liferay/js-publish'
about: Issues related to the @liferay/js-publish package
labels: npm-tools, js-publish
---

### Issue type (mark with `x`)

-   [ ] :thinking: Question
-   [ ] :bug: Bug report
-   [ ] :gift: Feature request
-   [ ] :woman_shrugging: Other

### Description

**Desired behavior:**

**Current behavior:**

**Repro instructions (if applicable):**

**Other information (environment, versions etc):**
