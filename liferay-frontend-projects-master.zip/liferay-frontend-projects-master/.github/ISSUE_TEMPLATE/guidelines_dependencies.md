---
name: 📦 Guidelines dependencies
about: Issues about adding new development dependencies
labels: guidelines,dependencies
---

<!--

For more info about adding a new devDependency,
see dxp/dev_dependencies.md document in this repo.

-->

## What is the new or updated dependency?

## Why is this dependency useful to you and others?

## What are the alternatives?
