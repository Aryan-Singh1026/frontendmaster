---
name: '⚙ @liferay/changelog-generator'
about: Issues related to the @liferay/changelog-generator package
labels: npm-tools, changelog-generator
---

### Issue type (mark with `x`)

-   [ ] :thinking: Question
-   [ ] :bug: Bug report
-   [ ] :gift: Feature request
-   [ ] :woman_shrugging: Other

### Description

**Desired behavior:**

**Current behavior:**

**Repro instructions (if applicable):**

**Other information (environment, versions etc):**
